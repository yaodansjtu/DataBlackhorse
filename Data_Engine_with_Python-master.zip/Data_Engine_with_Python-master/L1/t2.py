# 条件判断
score = 95
if score>= 90:
       print('Excellent')
else:
       if xscore < 60:
           print('Fail')
       else:
           print('Good Job')