# 列表
lists = ['zhangfei','guanyu','liubei']
# 列表中添加元素
lists.append('dianwei')
print(lists)
print(len(lists))
# 在指定位置添加元素
lists.insert(0,'diaochan')
# 删除末尾元素
lists.pop()
print(lists)