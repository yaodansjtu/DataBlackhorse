# 集合的使用
s = set(['zhangfei', 'guanyu', 'liubei'])
s.add('diaowei')
s.remove('zhangfei')
print(s)
print('liubei' in s)